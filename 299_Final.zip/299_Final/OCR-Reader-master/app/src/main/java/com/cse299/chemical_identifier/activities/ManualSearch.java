package com.cse299.chemical_identifier.activities;

import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.cse299.chemical_identifier.Database;
import com.cse299.chemical_identifier.R;

public class ManualSearch extends AppCompatActivity {
    private EditText mtext;
    private Button mbutton;
    private Database database1;
    private static final String TAG = "ManualSearchActivity";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual_search);
        mtext = (EditText) findViewById(R.id.manualText);
        mbutton= (Button) findViewById(R.id.mbutton1);

        mbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor cursor = database1.searchItem(mtext.getText().toString()) ;
                if(cursor!=null){
                    StringBuilder stringBuffer = new StringBuilder();
                    while(cursor.moveToNext())
                    {
                        stringBuffer.append("CHEMICAL_NAME : <b>"+cursor.getString(1)+"</b>\n\n\n");
                        stringBuffer.append("SHELF_LOCATION : <b>"+cursor.getString(4)+"</b>\n");
                        stringBuffer.append("DANGEROUS_LOCATION : <b>"+cursor.getString(5)+"</b>\n");
                        stringBuffer.append("DANGER_LEVEL : <b>"+cursor.getString(6)+"</b>\n\n");
                    }
                    AlertDialog.Builder builder = new AlertDialog.Builder(ManualSearch.this);
                    builder.setTitle("Search Result");
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                        builder.setMessage(Html.fromHtml(stringBuffer.toString(), Html.FROM_HTML_MODE_LEGACY));
                    } else {
                        builder.setMessage(Html.fromHtml(stringBuffer.toString())) ;
                    }
                    builder.setCancelable(true);
                    builder.show();
                }
                else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(ManualSearch.this);
                    builder.setTitle("Search Result");
                    builder.setMessage("NO results found");
                    builder.setCancelable(true);
                    builder.show();
                }
            }
        });
    }



}
