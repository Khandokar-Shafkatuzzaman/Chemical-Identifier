package com.cse299.chemical_identifier.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.cse299.chemical_identifier.R;

public class LoginActivity extends AppCompatActivity {
    EditText uname,pass;
    Button login1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);
        uname = (EditText)findViewById(R.id.userName);
        pass = (EditText)findViewById(R.id.passWord);
        login1 = (Button)findViewById(R.id.login);
    }

    public void movePage(View v) {

        String sname= uname.getText().toString();
        String spass= pass.getText().toString();
        if ( sname.equals("CSE299") && spass.equals("cse299")){
            openActivityDB();
        }
        else if (sname.equals("") || spass.equals("")){
            Toast.makeText(getApplicationContext(),"Enter Username and Password",Toast.LENGTH_SHORT).show();

        }else{
            Toast.makeText(getApplicationContext(),"Wrong Username and Password",Toast.LENGTH_SHORT).show();
        }
    }
    public void openActivityDB() {
        Intent intent = new Intent(this,DataBaseActivity.class);
        startActivity(intent);

    }
}
